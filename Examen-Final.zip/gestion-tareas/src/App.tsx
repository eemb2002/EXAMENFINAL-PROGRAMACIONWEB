import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import './App.css';
import Home from './components/Home';
import EmployeeManagement from './components/EmployeeManagement';
import ProjectManagement from './components/ProjectManagement';
import TaskManagement from './components/TaskManagement';

const App: React.FC = () => {
  return (
    <Router>
      <div className="App">
        <header className="App-header">
          <nav>
            <ul>
              <li><Link to="/">Home</Link></li>
              <li><Link to="/employees">Employee Management</Link></li>
              <li><Link to="/projects">Project Management</Link></li>
              <li><Link to="/tasks">Task Management</Link></li>
            </ul>
          </nav>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/employees" element={<EmployeeManagement />} />
            <Route path="/projects" element={<ProjectManagement />} />
            <Route path="/tasks" element={<TaskManagement />} />
          </Routes>
        </header>
      </div>
    </Router>
  );
};

export default App;
