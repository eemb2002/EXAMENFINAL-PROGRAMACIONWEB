import { Request, Response } from 'express';
import { db } from '../db';

export const getEmployees = async (req: Request, res: Response) => {
  try {
    const [employees] = await db.query('SELECT * FROM employees');
    res.json(employees);
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener los empleados', error });
  }
};
